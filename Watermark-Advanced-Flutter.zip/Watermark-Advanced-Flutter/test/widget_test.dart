import 'package:flutter_test/flutter_test.dart';
import 'package:watermark_advanced/main.dart';

void main() {
  testWidgets('shows the Watermark Advanced home screen', (tester) async {
    await tester.pumpWidget(const WatermarkApp());
    await tester.pumpAndSettle();
    expect(find.text('Watermark Advanced'), findsOneWidget);
    expect(find.text('إعداد العلامة المائية'), findsOneWidget);
  });
}
