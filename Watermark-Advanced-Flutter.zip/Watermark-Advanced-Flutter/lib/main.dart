import 'dart:io';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdfx/pdfx.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

void main() => runApp(const WatermarkApp());

enum AppThemeMode { system, light, dark, black }

class WatermarkApp extends StatefulWidget {
  const WatermarkApp({super.key});
  @override
  State<WatermarkApp> createState() => _WatermarkAppState();
}

class _WatermarkAppState extends State<WatermarkApp> {
  AppThemeMode mode = AppThemeMode.system;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final raw = p.getString('themeMode');
      if (raw != null && mounted) setState(() => mode = AppThemeMode.values.firstWhere((e) => e.name == raw, orElse: () => AppThemeMode.system));
    });
  }
  Future<void> setMode(AppThemeMode value) async {
    setState(() => mode = value);
    await (await SharedPreferences.getInstance()).setString('themeMode', value.name);
  }
  ThemeData theme(Brightness brightness, {bool pureBlack = false}) {
    final scheme = ColorScheme.fromSeed(seedColor: const Color(0xff3568d4), brightness: brightness);
    return ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: pureBlack ? Colors.black : null,
      cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
      inputDecorationTheme: InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
      appBarTheme: const AppBarTheme(centerTitle: false, scrolledUnderElevation: 0));
  }
  @override
  Widget build(BuildContext context) => MaterialApp(title: 'Watermark Advanced', debugShowCheckedModeBanner: false,
    theme: theme(Brightness.light), darkTheme: theme(Brightness.dark, pureBlack: mode == AppThemeMode.black), themeMode: mode == AppThemeMode.system ? ThemeMode.system : mode == AppThemeMode.light ? ThemeMode.light : ThemeMode.dark,
    home: HomePage(themeMode: mode, onThemeChanged: setMode));
}

class PdfItem {
  PdfItem({required this.name, required this.original, required this.current});
  final String name;
  final Uint8List original;
  Uint8List current;
  int get size => current.length;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.themeMode, required this.onThemeChanged});
  final AppThemeMode themeMode;
  final ValueChanged<AppThemeMode> onThemeChanged;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<PdfItem> files = [];
  final textController = TextEditingController(text: 'WATERMARK');
  final opacityController = TextEditingController(text: '0.22');
  final sizeController = TextEditingController(text: '36');
  Color watermarkColor = const Color(0xff3568d4);
  bool applyToAll = true;
  bool diagonal = true;
  bool busy = false;
  int selected = 0;
  String? status;
  PdfControllerPinch? previewController;

  @override
  void dispose() { textController.dispose(); opacityController.dispose(); sizeController.dispose(); previewController?.dispose(); super.dispose(); }

  Future<void> pickPdfs() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], allowMultiple: true, withData: true);
    if (result == null) return;
    final added = <PdfItem>[];
    for (final f in result.files) {
      final bytes = f.bytes ?? (f.path == null ? null : await File(f.path!).readAsBytes());
      if (bytes != null && bytes.isNotEmpty) added.add(PdfItem(name: f.name, original: Uint8List.fromList(bytes), current: Uint8List.fromList(bytes)));
    }
    if (!mounted) return;
    setState(() { files..clear()..addAll(added); selected = 0; status = added.isEmpty ? 'لم يتم تحميل ملفات صالحة.' : 'تم تحميل ${added.length} ملف PDF'; });
    _resetPreview();
  }
  void _resetPreview() {
    previewController?.dispose(); previewController = null;
    if (files.isNotEmpty) {
      final bytes = files[selected.clamp(0, files.length - 1)].current;
      // The preview is created lazily by the preview panel.
      if (mounted) setState(() {});
      _previewBytes = bytes;
    } else { _previewBytes = null; }
  }
  Uint8List? _previewBytes;

  Future<void> applyWatermark() async {
    if (files.isEmpty || busy) return;
    final label = textController.text.trim();
    if (label.isEmpty) { _message('اكتب نص العلامة المائية أولاً.'); return; }
    final opacity = (double.tryParse(opacityController.text) ?? .22).clamp(0.02, 1.0);
    final fontSize = (double.tryParse(sizeController.text) ?? 36).clamp(6, 180);
    setState(() { busy = true; status = 'جارٍ تعديل ملفات PDF…'; });
    try {
      final indexes = applyToAll ? List.generate(files.length, (i) => i) : [selected];
      for (final index in indexes) {
        final item = files[index];
        final document = PdfDocument(inputBytes: item.current);
        final brush = PdfSolidBrush(PdfColor(watermarkColor.red, watermarkColor.green, watermarkColor.blue, (opacity * 255).round()));
        final font = PdfStandardFont(PdfFontFamily.helvetica, fontSize.toDouble(), style: PdfFontStyle.bold);
        for (int i = 0; i < document.pages.count; i++) {
          final page = document.pages[i];
          final size = page.getClientSize();
          final graphics = page.graphics;
          if (diagonal) {
            graphics.save();
            graphics.translateTransform(size.width / 2, size.height / 2);
            graphics.rotateTransform(-35);
            final textSize = font.measureString(label);
            graphics.drawString(label, font, brush: brush, bounds: Rect.fromLTWH(-textSize.width / 2, -fontSize / 2, textSize.width + 4, fontSize * 1.6));
            graphics.restore();
          } else {
            graphics.drawString(label, font, brush: brush, bounds: Rect.fromLTWH(18, 18, size.width - 36, fontSize * 2));
          }
        }
        final output = await document.save();
        document.dispose();
        item.current = Uint8List.fromList(output);
      }
      _resetPreview();
      if (mounted) setState(() { status = 'تم تطبيق العلامة المائية بنجاح.'; });
    } catch (e) { if (mounted) setState(() => status = 'فشل التعديل: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> undo() async {
    if (files.isEmpty) return;
    setState(() { for (final i in (applyToAll ? List.generate(files.length, (i) => i) : [selected])) { files[i].current = Uint8List.fromList(files[i].original); } });
    _resetPreview(); _message('تمت استعادة النسخة الأصلية.');
  }

  Future<void> savePdf() async {
    if (files.isEmpty) return;
    if (files.length > 1 && applyToAll) { await saveZip(); return; }
    final item = files[selected];
    final path = await FilePicker.platform.saveFile(dialogTitle: 'حفظ ملف PDF', fileName: 'watermarked_${item.name}', type: FileType.custom, allowedExtensions: ['pdf'], bytes: item.current);
    if (path != null && mounted) _message('تم حفظ الملف.');
  }

  Future<void> saveZip() async {
    if (files.isEmpty || busy) return;
    setState(() { busy = true; status = 'جارٍ إنشاء ملف ZIP…'; });
    try {
      final archive = Archive();
      for (final item in files) {
        if (item.current.isEmpty) throw StateError('ملف فارغ: ${item.name}');
        final safeName = item.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
        archive.addFile(ArchiveFile(safeName, item.current.length, item.current));
      }
      final encoded = ZipEncoder().encode(archive);
      if (encoded == null || encoded.isEmpty) throw StateError('تعذر إنشاء الأرشيف.');
      final bytes = Uint8List.fromList(encoded);
      final check = ZipDecoder().decodeBytes(bytes, verify: true);
      if (check.files.length != files.length || check.files.any((f) => !f.isFile || f.size == 0)) throw StateError('فشل التحقق من محتويات ZIP.');
      final path = await FilePicker.platform.saveFile(dialogTitle: 'حفظ ملفات PDF كـ ZIP', fileName: 'watermarked_files.zip', type: FileType.custom, allowedExtensions: ['zip'], bytes: bytes);
      if (path != null && mounted) setState(() => status = 'تم إنشاء ZIP والتحقق من ${check.files.length} ملف.');
    } catch (e) { if (mounted) setState(() => status = 'فشل حفظ ZIP: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> shareProject() async {
    if (files.isEmpty) return;
    final dir = await getTemporaryDirectory();
    final item = files[selected];
    final f = File('${dir.path}/${item.name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_')}');
    await f.writeAsBytes(item.current, flush: true);
    await Share.shareXFiles([XFile(f.path)], text: 'Watermark Advanced');
  }
  void _message(String value) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value), behavior: SnackBarBehavior.floating)); }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Watermark Advanced', style: TextStyle(fontWeight: FontWeight.w700)), actions: [IconButton(tooltip: 'الإعدادات', onPressed: _openSettings, icon: const Icon(Icons.tune_rounded)), const SizedBox(width: 8)]),
      body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth >= 850;
        final controls = _controls(colors);
        final preview = _preview(colors);
        return SingleChildScrollView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 28), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _hero(colors), const SizedBox(height: 18),
          if (wide) Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 6, child: controls), const SizedBox(width: 16), Expanded(flex: 5, child: preview)])
          else ...[controls, const SizedBox(height: 16), preview],
          const SizedBox(height: 20), Center(child: TextButton.icon(onPressed: () => Share.share('Watermark Advanced · @SayedMohamaad\nhttps://t.me/SayedMohamaad'), icon: const Icon(Icons.telegram), label: const Text('Developed by @SayedMohamaad'))),
        ]));
      })),
    );
  }

  Widget _hero(ColorScheme colors) => Container(width: double.infinity, padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: LinearGradient(colors: [colors.primaryContainer, colors.secondaryContainer], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(28)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: colors.surface.withValues(alpha: .75), borderRadius: BorderRadius.circular(18)), child: Icon(Icons.picture_as_pdf_rounded, color: colors.primary, size: 30)),
    const SizedBox(height: 16), Text('علامتك المائية، بطريقتك', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: colors.onSurface)),
    const SizedBox(height: 6), Text('عدّل ملفات PDF واحفظها محليًا. ملفاتك لا تغادر جهازك.', style: TextStyle(color: colors.onSurfaceVariant, height: 1.5)),
    const SizedBox(height: 18), FilledButton.icon(onPressed: busy ? null : pickPdfs, icon: const Icon(Icons.add_rounded), label: Text(files.isEmpty ? 'اختيار ملفات PDF' : 'استبدال الملفات')),
  ]));

  Widget _controls(ColorScheme colors) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _sectionTitle('إعداد العلامة المائية', Icons.water_drop_outlined), const SizedBox(height: 10),
    Card(color: colors.surfaceContainerLow, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      TextField(controller: textController, decoration: const InputDecoration(labelText: 'نص العلامة المائية', hintText: 'مثال: CONFIDENTIAL', prefixIcon: Icon(Icons.title_rounded))),
      const SizedBox(height: 12), Row(children: [Expanded(child: TextField(controller: sizeController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'حجم الخط', suffixText: 'px'))), const SizedBox(width: 12), Expanded(child: TextField(controller: opacityController, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'الشفافية', hintText: '0.22', helperText: 'من 0.02 إلى 1.0')))]),
      const SizedBox(height: 12), InkWell(borderRadius: BorderRadius.circular(16), onTap: _pickColor, child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outlineVariant)), child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: watermarkColor, borderRadius: BorderRadius.circular(12))), const SizedBox(width: 12), const Expanded(child: Text('لون العلامة المائية')), Text('#${watermarkColor.value.toRadixString(16).substring(2).toUpperCase()}'), const SizedBox(width: 8), const Icon(Icons.chevron_right_rounded)]))),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: diagonal, onChanged: (v) => setState(() => diagonal = v), title: const Text('علامة مائية مائلة'), subtitle: const Text('تظهر في منتصف الصفحة')),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: applyToAll, onChanged: (v) => setState(() => applyToAll = v), title: const Text('تطبيق على كل الملفات'), subtitle: Text(applyToAll ? 'سيتم تعديل ${files.length} ملف' : 'تعديل الملف المحدد فقط')),
      const SizedBox(height: 8), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy || files.isEmpty ? null : applyWatermark, icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_fix_high_rounded), label: Text(busy ? 'جارٍ التنفيذ…' : 'تطبيق العلامة المائية'))),
    ]))),
    const SizedBox(height: 18), _sectionTitle('ملفاتك', Icons.folder_open_rounded), const SizedBox(height: 10),
    if (files.isEmpty) Card(color: colors.surfaceContainerLow, child: const Padding(padding: EdgeInsets.all(24), child: Center(child: Column(children: [Icon(Icons.upload_file_rounded, size: 38), SizedBox(height: 8), Text('اختر ملف PDF للبدء')]))))
    else Card(color: colors.surfaceContainerLow, child: Column(children: [for (int i = 0; i < files.length; i++) ListTile(selected: selected == i, leading: CircleAvatar(child: const Icon(Icons.picture_as_pdf_rounded)), title: Text(files[i].name, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text('${(files[i].size / 1024).toStringAsFixed(0)} KB'), trailing: selected == i ? Icon(Icons.check_circle, color: colors.primary) : null, onTap: () { setState(() => selected = i); _resetPreview(); }), if (i < files.length - 1) const Divider(height: 1, indent: 16, endIndent: 16)])),
    const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: files.isEmpty || busy ? null : undo, icon: const Icon(Icons.restart_alt_rounded), label: const Text('استعادة الأصل'))), const SizedBox(width: 10), Expanded(child: FilledButton.tonalIcon(onPressed: files.isEmpty || busy ? null : savePdf, icon: const Icon(Icons.save_alt_rounded), label: Text(files.length > 1 && applyToAll ? 'حفظ ZIP' : 'حفظ PDF')))]),
    if (files.length > 1) Padding(padding: const EdgeInsets.only(top: 8), child: SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: busy ? null : saveZip, icon: const Icon(Icons.archive_outlined), label: const Text('حفظ جميع الملفات كـ ZIP')))),
    if (status != null) Padding(padding: const EdgeInsets.only(top: 12), child: Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: colors.secondaryContainer, borderRadius: BorderRadius.circular(14)), child: Text(status!, style: TextStyle(color: colors.onSecondaryContainer)))),
  ]);

  Widget _preview(ColorScheme colors) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _sectionTitle('المعاينة', Icons.preview_rounded), const SizedBox(height: 10),
    Container(height: 440, width: double.infinity, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(color: colors.surfaceContainerHighest, borderRadius: BorderRadius.circular(24), border: Border.all(color: colors.outlineVariant)), child: files.isEmpty ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.description_outlined, size: 54, color: colors.onSurfaceVariant), const SizedBox(height: 10), Text('ستظهر معاينة PDF هنا', style: TextStyle(color: colors.onSurfaceVariant))])) : _PdfPreview(key: ValueKey('${selected}_${files[selected].current.length}_${files[selected].current.hashCode}'), bytes: files[selected].current)),
    const SizedBox(height: 10), OutlinedButton.icon(onPressed: files.isEmpty ? null : shareProject, icon: const Icon(Icons.share_rounded), label: const Text('مشاركة الملف المحدد')),
  ]);

  Widget _sectionTitle(String text, IconData icon) => Row(children: [Icon(icon, size: 21, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 8), Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))]);

  Future<void> _pickColor() async {
    Color temp = watermarkColor;
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(title: const Text('اختيار اللون'), content: SingleChildScrollView(child: ColorPicker(pickerColor: temp, onColorChanged: (c) => temp = c, enableAlpha: false, labelTypes: const [])), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')), FilledButton(onPressed: () { setState(() => watermarkColor = temp); Navigator.pop(ctx); }, child: const Text('تطبيق'))]));
  }
  Future<void> _openSettings() async {
    await showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true, builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 28), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('الإعدادات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('المظهر'), const SizedBox(height: 8), for (final item in AppThemeMode.values) RadioListTile<AppThemeMode>(value: item, groupValue: widget.themeMode, onChanged: (v) { if (v != null) { widget.onThemeChanged(v); Navigator.pop(ctx); } }, title: Text(switch (item) { AppThemeMode.system => 'تلقائي حسب النظام', AppThemeMode.light => 'فاتح', AppThemeMode.dark => 'داكن', AppThemeMode.black => 'أسود AMOLED' }), secondary: Icon(switch (item) { AppThemeMode.system => Icons.brightness_auto_rounded, AppThemeMode.light => Icons.light_mode_rounded, AppThemeMode.dark => Icons.dark_mode_rounded, AppThemeMode.black => Icons.contrast_rounded })), const Divider(), const ListTile(leading: Icon(Icons.offline_bolt_outlined), title: Text('يعمل محليًا'), subtitle: Text('لا يتم رفع ملفات PDF إلى خادم')), const ListTile(leading: Icon(Icons.person_outline), title: Text('المطور'), subtitle: Text('@SayedMohamaad'))]))));
  }
}

class _PdfPreview extends StatefulWidget {
  const _PdfPreview({super.key, required this.bytes});
  final Uint8List bytes;
  @override
  State<_PdfPreview> createState() => _PdfPreviewState();
}
class _PdfPreviewState extends State<_PdfPreview> {
  PdfControllerPinch? controller;
  @override
  void initState() { super.initState(); _init(); }
  Future<void> _init() async { try { final doc = await PdfDocument.openData(widget.bytes); if (mounted) setState(() => controller = PdfControllerPinch(document: Future.value(doc))); } catch (_) {} }
  @override
  void dispose() { controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => controller == null ? const Center(child: CircularProgressIndicator()) : PdfViewPinch(controller: controller!, builders: PdfViewPinchBuilders<DefaultBuilderOptions>(options: const DefaultBuilderOptions(), documentLoaderBuilder: (_) => const Center(child: CircularProgressIndicator()), pageLoaderBuilder: (_) => const Center(child: CircularProgressIndicator()), errorBuilder: (_, error) => Center(child: Padding(padding: const EdgeInsets.all(16), child: Text('تعذرت المعاينة: $error')))));
}
